from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def homepageview(request):
    return HttpResponse("<h1><i>Welcome to My homepage</i></h1>")

def aboutpageview(request):
    return HttpResponse("<h1><i>Welcome to My about us page</i></h1>")

def contactpageview(request):
    return HttpResponse("<h1><i>Welcome to My contact us page</i></h1>")