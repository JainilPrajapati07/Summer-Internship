from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def homepageview(request):
    return render(request,'home.html')

def aboutpageview(request):
    return render(request,'about.html')

def contactpageview(request):
    return render(request,'contact.html')

def registrationform(request):
    return render(request,'registration.html')

def form(request):
    print(request.method)
    print(request.POST)
    Firstname = request.POST['firstname']
    Middlename = request.POST['middlename']
    Lastname = request.POST['lastname']
    Course = request.POST['course']
    Gender = request.POST['gender']
    Phone = request.POST['phone']
    Address = request.POST['address']
    Email = request.POST['email']
    return render(request,'data.html',{'Firstname':Firstname,'Middlename':Middlename,
    'Lastname':Lastname,'Course':Course,'Gender':Gender,'Phone':Phone,'Address':Address,'Email':Email})

